export default function About() {
    return(
        <div>
            <p>About Page</p>
        </div>
    )
}